import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# If you prefer matplotlib styling, you can comment out seaborn
sns.set_style("whitegrid")

# List of species
species_list = ["mzeb", "onil", "salicaceae"]

shape_data = []
comparison_data = []

for sp in species_list:
    # Read the shape metrics
    shape_df = pd.read_csv(f"tree_shape_metrics_{sp}.csv")
    # Add a column for species
    shape_df["Species"] = sp
    shape_data.append(shape_df)
    
    # Read the comparison metrics
    comp_df = pd.read_csv(f"tree_comparison_metrics_{sp}.csv")
    comp_df["Species"] = sp
    comparison_data.append(comp_df)

# Concatenate all species data
shape_all = pd.concat(shape_data, ignore_index=True)
comparison_all = pd.concat(comparison_data, ignore_index=True)

### Plot 1: Sackin Index Comparison Across Species

plt.figure(figsize=(8,6))
sns.barplot(data=shape_all, x="Species", y="Sackin Index", hue="Tree Label", ci=None)
plt.title("Sackin Index Across Species and Methods")
plt.ylabel("Sackin Index")
plt.legend(title="Method", bbox_to_anchor=(1.05, 1), loc='upper left')
plt.tight_layout()

# Save the figure before showing it
plt.savefig("sackin_index_comparison.png", dpi=300)
plt.show()

### Plot 2: Robinson-Foulds Distance Comparison Across Species

plt.figure(figsize=(10,6))
sns.barplot(data=comparison_all, x="Species", y="Robinson-Foulds Distance", hue="Tree Pair", ci=None)
plt.title("Robinson-Foulds Distance Across Species and Tree Pairs")
plt.ylabel("Robinson-Foulds Distance")
plt.legend(title="Tree Pair", bbox_to_anchor=(1.05, 1), loc='upper left')
plt.tight_layout()

# Save the figure before showing it
plt.savefig("rf_distance_comparison.png", dpi=300)
plt.show()
